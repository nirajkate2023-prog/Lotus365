<#
.SYNOPSIS
    Pushes all Lotus365 website files directly to GitHub (nirajkate2023-prog/Lotus365) via GitHub REST API.
    Does not require git.exe or admin rights!
#>

param(
    [Parameter(Mandatory=$false)]
    [string]$Token = "",
    [string]$Owner = "nirajkate2023-prog",
    [string]$Repo = "Lotus365",
    [string]$Branch = "main"
)

$ErrorActionPreference = "Stop"

if (-not $Token) {
    if ($env:GITHUB_TOKEN) {
        $Token = $env:GITHUB_TOKEN
    } else {
        $Token = Read-Host "Please enter your GitHub Personal Access Token (classic 'repo' scope or fine-grained 'Contents: Read and Write')"
    }
}

if (-not $Token) {
    Write-Host "Error: GitHub Personal Access Token is required." -ForegroundColor Red
    exit 1
}

$headers = @{
    "Authorization"        = "Bearer $Token"
    "Accept"               = "application/vnd.github+json"
    "User-Agent"           = "Lotus365-Deploy-Tool"
    "X-GitHub-Api-Version" = "2022-11-28"
}

Write-Host "Verifying GitHub authentication..." -ForegroundColor Cyan
try {
    $authUser = Invoke-RestMethod -Uri "https://api.github.com/user" -Headers $headers -Method Get
    Write-Host "Logged in as: $($authUser.login)" -ForegroundColor Green
} catch {
    Write-Host "Authentication failed. Please check your token." -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

Write-Host "Fetching latest commit on branch '$Branch' of $Owner/$Repo..." -ForegroundColor Cyan
try {
    $refInfo = Invoke-RestMethod -Uri "https://api.github.com/repos/$Owner/$Repo/git/ref/heads/$Branch" -Headers $headers -Method Get
    $parentCommitSha = $refInfo.object.sha
    $parentCommit = Invoke-RestMethod -Uri "https://api.github.com/repos/$Owner/$Repo/git/commits/$parentCommitSha" -Headers $headers -Method Get
    $baseTreeSha = $parentCommit.tree.sha
    Write-Host "Latest commit: $parentCommitSha" -ForegroundColor Gray
} catch {
    Write-Host "Failed to get branch ref: $_" -ForegroundColor Red
    exit 1
}

$rootPath = $PSScriptRoot
if (-not $rootPath) {
    $rootPath = "c:\Users\User\Downloads\gaming-website"
}

# Collect files to upload (exclude the script itself and git folders)
$files = Get-ChildItem -Path $rootPath -Recurse -File | Where-Object {
    $_.FullName -notmatch "\\\.git" -and
    $_.Name -ne "push_to_github.ps1"
}

Write-Host "Uploading $($files.Count) files as Git blobs..." -ForegroundColor Cyan
$treeEntries = [System.Collections.Generic.List[PSCustomObject]]::new()

$count = 0
foreach ($file in $files) {
    $count++
    # Calculate relative path with forward slashes
    $relPath = $file.FullName.Substring($rootPath.Length).TrimStart('\', '/').Replace('\', '/')
    
    $bytes = [System.IO.File]::ReadAllBytes($file.FullName)
    $b64 = [System.Convert]::ToBase64String($bytes)
    
    $blobPayload = @{
        content  = $b64
        encoding = "base64"
    } | ConvertTo-Json
    
    Write-Host "[$count/$($files.Count)] Uploading $relPath..." -ForegroundColor DarkGray
    $blobRes = Invoke-RestMethod -Uri "https://api.github.com/repos/$Owner/$Repo/git/blobs" -Headers $headers -Method Post -Body $blobPayload
    
    $treeEntries.Add([PSCustomObject]@{
        path = $relPath
        mode = "100644"
        type = "blob"
        sha  = $blobRes.sha
    })
}

Write-Host "Creating new Git tree..." -ForegroundColor Cyan
$treePayload = @{
    base_tree = $baseTreeSha
    tree      = $treeEntries
} | ConvertTo-Json -Depth 5

$newTree = Invoke-RestMethod -Uri "https://api.github.com/repos/$Owner/$Repo/git/trees" -Headers $headers -Method Post -Body $treePayload
Write-Host "New tree SHA: $($newTree.sha)" -ForegroundColor Gray

Write-Host "Creating commit..." -ForegroundColor Cyan
$commitPayload = @{
    message = "Fix deployment structure: Move Lotus365 files to root, add 404, .nojekyll, and GitHub Pages workflow"
    tree    = $newTree.sha
    parents = @($parentCommitSha)
} | ConvertTo-Json

$newCommit = Invoke-RestMethod -Uri "https://api.github.com/repos/$Owner/$Repo/git/commits" -Headers $headers -Method Post -Body $commitPayload
Write-Host "New commit SHA: $($newCommit.sha)" -ForegroundColor Gray

Write-Host "Updating branch '$Branch' reference to point to new commit..." -ForegroundColor Cyan
$refPayload = @{
    sha   = $newCommit.sha
    force = $true
} | ConvertTo-Json

$updatedRef = Invoke-RestMethod -Uri "https://api.github.com/repos/$Owner/$Repo/git/refs/heads/$Branch" -Headers $headers -Method Patch -Body $refPayload

Write-Host "`nSUCCESS! Repository $Owner/$Repo has been updated!" -ForegroundColor Green
Write-Host "New commit: $($newCommit.sha)" -ForegroundColor Green
Write-Host "View changes live at: https://github.com/$Owner/$Repo" -ForegroundColor Green
